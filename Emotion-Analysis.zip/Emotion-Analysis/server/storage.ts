import { db } from "./db";
import { analyses, type InsertAnalysis, type Analysis } from "@shared/schema";
import { desc } from "drizzle-orm";

export interface IStorage {
  getAnalyses(): Promise<Analysis[]>;
  createAnalysis(data: { text: string; emotion: string; scores: any }): Promise<Analysis>;
}

export class DatabaseStorage implements IStorage {
  async getAnalyses(): Promise<Analysis[]> {
    return await db.select().from(analyses).orderBy(desc(analyses.createdAt));
  }

  async createAnalysis(data: { text: string; emotion: string; scores: any }): Promise<Analysis> {
    const [analysis] = await db.insert(analyses).values(data).returning();
    return analysis;
  }
}

export const storage = new DatabaseStorage();
