import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

// Replit AI integration for OpenAI access
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

async function analyzeEmotionWithAI(text: string): Promise<{main: string, scores: Record<string, number>}> {
  const emotions = [
    'joy', 'sadness', 'anger', 'fear', 'surprise', 
    'disgust', 'trust', 'anticipation', 'love', 'optimism'
  ];

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "system",
        content: `You are an expert psychologist and sentiment analyst. Analyze the emotional content of the provided text with extreme precision.
        
        Rules:
        1. Evaluate the text across all 10 emotional dimensions: ${emotions.join(', ')}.
        2. Assign an intensity score (0.0 to 1.0) to each emotion.
        3. Be nuanced. A text can have multiple high scores (e.g., Love and Joy).
        4. "main" should be the single most defining emotion.
        
        Return a valid JSON object with:
        {
          "main": "dominant_emotion",
          "scores": { "joy": 0.8, "sadness": 0.1, ... }
        }`
      },
      {
        role: "user",
        content: text
      }
    ],
    response_format: { type: "json_object" }
  });

  const content = response.choices[0].message.content;
  if (!content) throw new Error("Empty response from OpenAI");
  
  const parsed = JSON.parse(content);
  
  const finalScores: Record<string, number> = {};
  emotions.forEach(e => {
    finalScores[e] = typeof parsed.scores[e] === 'number' ? parsed.scores[e] : 0.0;
  });

  return {
    main: parsed.main || emotions[0],
    scores: finalScores
  };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.analyses.list.path, async (req, res) => {
    const history = await storage.getAnalyses();
    res.status(200).json(history);
  });

  app.post(api.analyses.create.path, async (req, res) => {
    try {
      const input = api.analyses.create.input.parse(req.body);
      
      let analysisResult;
      try {
        analysisResult = await analyzeEmotionWithAI(input.text);
      } catch (err) {
        console.error("AI Analysis failed", err);
        analysisResult = { 
          main: "neutral", 
          scores: { joy: 0.1, sadness: 0.1, anger: 0.1, fear: 0.1, surprise: 0.1, disgust: 0.1, trust: 0.1, anticipation: 0.1, love: 0.1, optimism: 0.1 } 
        };
      }
      
      const analysis = await storage.createAnalysis({
        text: input.text,
        emotion: analysisResult.main,
        scores: analysisResult.scores
      });
      
      res.status(201).json(analysis);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
