## Packages
framer-motion | Smooth page transitions and delightful micro-interactions for the emotion results
date-fns | Elegant date formatting for the history sidebar

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
}
