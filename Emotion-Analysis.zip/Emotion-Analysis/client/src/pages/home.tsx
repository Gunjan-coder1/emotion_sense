import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, ArrowRight, CornerDownLeft, BarChart3 } from "lucide-react";
import { useAnalyses, useCreateAnalysis } from "@/hooks/use-analyses";
import { EmotionBadge } from "@/components/emotion-badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";

export default function Home() {
  const [match, params] = useRoute("/analysis/:id");
  const [, setLocation] = useLocation();
  const [text, setText] = useState("");
  
  const { data: analyses } = useAnalyses();
  const createAnalysis = useCreateAnalysis();

  const viewId = match && params?.id ? parseInt(params.id) : null;
  const viewedAnalysis = viewId && analyses ? analyses.find(a => a.id === viewId) : null;

  useEffect(() => {
    if (!viewId) {
      setText("");
    }
  }, [viewId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;

    createAnalysis.mutate(
      { text: text.trim() },
      {
        onSuccess: (data) => {
          setLocation(`/analysis/${data.id}`);
        },
      }
    );
  };

  const isPending = createAnalysis.isPending;

  return (
    <div className="flex-1 h-screen overflow-y-auto bg-background/50 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-background to-background">
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20 min-h-full flex flex-col">
        
        <AnimatePresence mode="wait">
          {!viewedAnalysis ? (
            <motion.div
              key="compose"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex-1 flex flex-col"
            >
              <div className="mb-10 text-center">
                <h2 className="text-5xl md:text-6xl font-display font-bold text-foreground mb-6 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-600">
                  Understand your emotions.
                </h2>
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
                  Our advanced AI analyzes your text across 10 distinct emotional scales to give you a precise understanding of your sentiment.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="flex-1 flex flex-col relative">
                <div className="relative flex-1 min-h-[350px] mb-8 rounded-[2rem] overflow-hidden bg-card/80 backdrop-blur-sm border-2 border-border shadow-xl transition-all duration-500 focus-within:border-primary/30 focus-within:shadow-primary/5 focus-within:ring-8 focus-within:ring-primary/5">
                  <Textarea
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Express yourself here..."
                    className="w-full h-full min-h-[350px] p-8 md:p-10 text-xl md:text-2xl leading-relaxed resize-none border-0 focus-visible:ring-0 bg-transparent placeholder:text-muted-foreground/30 font-medium"
                    disabled={isPending}
                  />
                  
                  <div className="absolute bottom-8 left-10 text-muted-foreground/40 flex items-center gap-3 text-sm font-semibold tracking-wide uppercase pointer-events-none">
                    <CornerDownLeft className="w-4 h-4" />
                    Press Analyze to begin
                  </div>
                </div>

                <div className="flex justify-center">
                  <Button 
                    type="submit" 
                    size="lg"
                    disabled={!text.trim() || isPending}
                    className="rounded-full px-12 py-8 text-lg font-bold shadow-2xl shadow-primary/30 hover:shadow-primary/40 hover:-translate-y-1 active:translate-y-0 transition-all duration-300 bg-gradient-to-r from-primary to-purple-600 border-none"
                  >
                    {isPending ? (
                      <>
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                          className="mr-3"
                        >
                          <Sparkles className="w-6 h-6 text-white" />
                        </motion.div>
                        Decoding Emotions...
                      </>
                    ) : (
                      <>
                        Analyze Emotion
                        <ArrowRight className="ml-3 h-6 w-6" />
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </motion.div>
          ) : (
            <motion.div
              key="view"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex-1 flex flex-col w-full gap-12"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
                <div className="space-y-8">
                  <div className="p-8 md:p-10 bg-card rounded-[2.5rem] border-2 border-border/50 shadow-2xl relative overflow-hidden min-h-[300px] flex items-center">
                    <div className="absolute top-6 left-8 text-9xl leading-none font-display text-primary/5 select-none pointer-events-none italic">
                      "
                    </div>
                    <p className="text-2xl md:text-3xl leading-relaxed text-foreground font-semibold relative z-10 italic">
                      {viewedAnalysis.text}
                    </p>
                  </div>
                  
                  <div className="flex justify-center pt-4">
                    <Button 
                      variant="outline" 
                      size="lg"
                      onClick={() => setLocation("/")}
                      className="rounded-full px-10 py-6 text-base font-bold bg-background hover:bg-muted transition-all border-2 shadow-sm"
                    >
                      New Analysis
                    </Button>
                  </div>
                </div>

                <Card className="p-8 md:p-10 rounded-[2.5rem] border-2 border-primary/10 shadow-2xl bg-card/50 backdrop-blur-md">
                  <div className="flex items-center gap-3 mb-8">
                    <BarChart3 className="w-6 h-6 text-primary" />
                    <h3 className="text-xl font-bold tracking-tight">Emotional Spectrum</h3>
                  </div>

                  <div className="space-y-6">
                    {Object.entries(viewedAnalysis.scores as Record<string, number>)
                      .sort(([, a], [, b]) => b - a)
                      .map(([emotion, score]) => (
                        <div key={emotion} className="space-y-2">
                          <div className="flex justify-between items-center px-1">
                            <span className="text-sm font-bold uppercase tracking-wider text-foreground/80 flex items-center gap-2">
                              <EmotionBadge emotion={emotion} size="sm" />
                              {emotion}
                            </span>
                            <span className="text-sm font-black text-primary">
                              {Math.round(score * 100)}%
                            </span>
                          </div>
                          <Progress value={score * 100} className="h-3 bg-muted/50" />
                        </div>
                      ))}
                  </div>
                </Card>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
