import { getEmotionConfig } from "@/lib/emotion-config";
import { motion } from "framer-motion";

interface EmotionBadgeProps {
  emotion: string;
  size?: "sm" | "lg";
  animated?: boolean;
}

export function EmotionBadge({ emotion, size = "sm", animated = false }: EmotionBadgeProps) {
  const config = getEmotionConfig(emotion);
  const isLarge = size === "lg";

  const BadgeContent = (
    <div
      className={`
        inline-flex items-center justify-center font-medium capitalize tracking-wide
        border rounded-full backdrop-blur-sm
        ${config.bg} ${config.text} ${config.border}
        ${isLarge 
          ? "px-6 py-2.5 text-lg shadow-lg gap-3" 
          : "px-3 py-1 text-xs shadow-sm gap-1.5"}
      `}
    >
      <span className={isLarge ? "text-2xl" : "text-sm"}>{config.icon}</span>
      <span>{emotion}</span>
    </div>
  );

  if (animated) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      >
        {BadgeContent}
      </motion.div>
    );
  }

  return BadgeContent;
}
