import { Link, useLocation } from "wouter";
import { format } from "date-fns";
import { Plus, History, Fingerprint } from "lucide-react";
import { useAnalyses } from "@/hooks/use-analyses";
import { EmotionBadge } from "./emotion-badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarHeader,
} from "@/components/ui/sidebar";

export function AppSidebar() {
  const [location] = useLocation();
  const { data: analyses, isLoading } = useAnalyses();

  const sortedAnalyses = analyses ? [...analyses].sort((a, b) => {
    return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
  }) : [];

  return (
    <Sidebar className="border-r-2 border-border/40 bg-background/80 backdrop-blur-2xl">
      <SidebarHeader className="p-6 pt-10">
        <div className="flex items-center gap-3 px-2 pb-8">
          <div className="bg-gradient-to-br from-primary to-purple-600 text-primary-foreground p-3 rounded-2xl shadow-lg shadow-primary/20">
            <Fingerprint className="w-6 h-6" />
          </div>
          <h1 className="font-display font-black text-2xl tracking-tighter">emotionSense</h1>
        </div>
        
        <Button asChild className="w-full justify-center rounded-2xl h-14 font-bold text-base shadow-xl shadow-primary/10 hover:shadow-primary/20 hover:-translate-y-0.5 transition-all bg-primary">
          <Link href="/">
            <Plus className="mr-2 h-5 w-5" />
            New Scan
          </Link>
        </Button>
      </SidebarHeader>

      <SidebarContent className="px-3">
        <SidebarGroup>
          <SidebarGroupLabel className="px-4 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 flex items-center gap-2 mb-4">
            <History className="w-3.5 h-3.5" />
            Archive
          </SidebarGroupLabel>
          <SidebarGroupContent>
            {isLoading ? (
              <div className="px-4 space-y-4 mt-2">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="space-y-3">
                    <Skeleton className="h-5 w-full rounded-lg" />
                    <Skeleton className="h-4 w-1/2 rounded-lg" />
                  </div>
                ))}
              </div>
            ) : sortedAnalyses.length === 0 ? (
              <div className="px-6 py-12 text-center">
                <p className="text-sm font-medium text-muted-foreground/50 italic">
                  Your emotional archive is empty.
                </p>
              </div>
            ) : (
              <SidebarMenu className="space-y-2">
                {sortedAnalyses.map((item) => {
                  const isSelected = location === `/analysis/${item.id}`;
                  return (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton 
                        asChild 
                        isActive={isSelected}
                        className={`
                          h-auto py-4 px-4 rounded-[1.25rem] transition-all duration-300 border-2
                          ${isSelected 
                            ? 'bg-primary/10 border-primary/20 shadow-md ring-4 ring-primary/5' 
                            : 'bg-transparent border-transparent hover:border-border/60 hover:bg-muted/30'}
                        `}
                      >
                        <Link href={`/analysis/${item.id}`} className="flex flex-col items-start gap-3">
                          <p className={`text-sm font-bold line-clamp-2 leading-snug ${isSelected ? 'text-primary' : 'text-foreground/80'}`}>
                            {item.text}
                          </p>
                          <div className="flex items-center justify-between w-full">
                            <EmotionBadge emotion={item.emotion} size="sm" />
                            <span className="text-[10px] font-black text-muted-foreground/40 uppercase tracking-tighter">
                              {item.createdAt ? format(new Date(item.createdAt), 'MMM d') : ''}
                            </span>
                          </div>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            )}
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
