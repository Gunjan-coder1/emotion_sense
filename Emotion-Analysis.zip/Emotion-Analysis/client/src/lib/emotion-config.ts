export type EmotionConfig = {
  bg: string;
  text: string;
  border: string;
  shadow: string;
  icon: string;
};

export const emotionsMap: Record<string, EmotionConfig> = {
  joy: { bg: 'bg-[#FEF08A]/20', text: 'text-[#854D0E]', border: 'border-[#FDE047]/50', shadow: 'shadow-[#FEF08A]/20', icon: '✨' },
  sadness: { bg: 'bg-[#DBEAFE]/30', text: 'text-[#1E40AF]', border: 'border-[#BFDBFE]/50', shadow: 'shadow-[#DBEAFE]/20', icon: '🌧️' },
  anger: { bg: 'bg-[#FEE2E2]/30', text: 'text-[#991B1B]', border: 'border-[#FECACA]/50', shadow: 'shadow-[#FEE2E2]/20', icon: '🔥' },
  fear: { bg: 'bg-[#F3E8FF]/40', text: 'text-[#6B21A8]', border: 'border-[#E9D5FF]/50', shadow: 'shadow-[#F3E8FF]/20', icon: '👀' },
  surprise: { bg: 'bg-[#FFEDD5]/40', text: 'text-[#9A3412]', border: 'border-[#FED7AA]/50', shadow: 'shadow-[#FFEDD5]/20', icon: '😲' },
  disgust: { bg: 'bg-[#DCFCE7]/40', text: 'text-[#166534]', border: 'border-[#BBF7D0]/50', shadow: 'shadow-[#DCFCE7]/20', icon: '🤢' },
  anticipation: { bg: 'bg-[#CCFBF1]/40', text: 'text-[#065F46]', border: 'border-[#A7F3D0]/50', shadow: 'shadow-[#CCFBF1]/20', icon: '⏳' },
  trust: { bg: 'bg-[#E0F2FE]/40', text: 'text-[#1E3A8A]', border: 'border-[#BAE6FD]/50', shadow: 'shadow-[#E0F2FE]/20', icon: '🤝' },
  neutral: { bg: 'bg-[#F3F4F6]', text: 'text-[#374151]', border: 'border-[#E5E7EB]', shadow: 'shadow-[#F3F4F6]/20', icon: '😐' },
  love: { bg: 'bg-[#FCE7F3]/50', text: 'text-[#9D174D]', border: 'border-[#FBCFE8]/60', shadow: 'shadow-[#FCE7F3]/20', icon: '💖' },
  optimism: { bg: 'bg-[#FEF9C3]/50', text: 'text-[#854D0E]', border: 'border-[#FEF08A]/60', shadow: 'shadow-[#FEF9C3]/20', icon: '🌅' },
  pessimism: { bg: 'bg-[#E2E8F0]/50', text: 'text-[#1E293B]', border: 'border-[#CBD5E1]/60', shadow: 'shadow-[#E2E8F0]/20', icon: '⛈️' },
  anxiety: { bg: 'bg-[#EDE9FE]/50', text: 'text-[#5B21B6]', border: 'border-[#DDD6FE]/60', shadow: 'shadow-[#EDE9FE]/20', icon: '😰' },
  relief: { bg: 'bg-[#D1FAE5]/50', text: 'text-[#065F46]', border: 'border-[#A7F3D0]/60', shadow: 'shadow-[#D1FAE5]/20', icon: '😌' },
  guilt: { bg: 'bg-[#FFEDD5]/50', text: 'text-[#9A3412]', border: 'border-[#FED7AA]/60', shadow: 'shadow-[#FFEDD5]/20', icon: '🫣' },
};

export function getEmotionConfig(emotion: string): EmotionConfig {
  const normalized = emotion.toLowerCase().trim();
  return emotionsMap[normalized] || emotionsMap.neutral;
}
