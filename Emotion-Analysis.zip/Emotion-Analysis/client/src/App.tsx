import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import NotFound from "@/pages/not-found";
import Home from "./pages/home";
import { AppSidebar } from "./components/app-sidebar";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/analysis/:id" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const style = {
    "--sidebar-width": "24rem",
  } as React.CSSProperties;

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider style={style}>
          <div className="flex h-screen w-full overflow-hidden bg-background">
            <AppSidebar />
            
            <div className="flex flex-col flex-1 min-w-0 relative">
              <header className="md:hidden flex items-center justify-between p-6 border-b bg-background/80 backdrop-blur-md absolute top-0 left-0 right-0 z-50">
                <div className="flex items-center gap-3">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                  <span className="font-display font-black text-xl tracking-tighter text-primary">emotionSense</span>
                </div>
              </header>
              
              <div className="hidden md:block absolute top-8 left-8 z-50">
                <SidebarTrigger className="h-12 w-12 rounded-2xl bg-background/80 backdrop-blur-sm border-2 shadow-xl hover:scale-110 transition-transform active:scale-95" />
              </div>

              <main className="flex-1 overflow-hidden flex flex-col pt-[88px] md:pt-0">
                <Router />
              </main>
            </div>
          </div>
        </SidebarProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
